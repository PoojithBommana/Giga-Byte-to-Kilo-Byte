Gigabyte = float(input())
kilobyte = Gigabyte *1000
print(kilobyte)